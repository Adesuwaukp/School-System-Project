/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.context.FacesContext;

/**
 *
 * @author Adesuwa
 */

@Named(value = "login")
@SessionScoped
 public class login implements Serializable{

    private String id;
    private String type;
    private options theLoginAccount;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public options getTheLoginAccount() {
        return theLoginAccount;
    }

    public void setTheLoginAccount(options theLoginAccount) {
        this.theLoginAccount = theLoginAccount;
    }
    
    
    
    
    public String login() {
        
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return ("Internal Error");
        }
         final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/ukponmwana8241?useSSL=false";
         Connection conn = null;
         Statement st = null;
         ResultSet rs = null;
         
        try
        {
          conn = DriverManager.getConnection(DB_URL, "ukponmwana8241", "1596850");
          st = conn.createStatement();
          rs = st.executeQuery("select * from account where id = '" + id + "'");
          
          if(rs.next())
          {
              if(type.equals(rs.getString(2)))
              {
                  theLoginAccount = new options(id, type);
                  return ("welcome");
              }
              else
              {
                  id="";
                  type="";
                  return ("loginNotSuccessful");
              }
          }
          else
          {
              id="";
              type="";
              return ("userNotExist");
          }
           
           
        }
        catch(SQLException e)
        {
           e.printStackTrace();
           return ("Internal Error");
        }
        finally
        {
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }        
    }   
}
