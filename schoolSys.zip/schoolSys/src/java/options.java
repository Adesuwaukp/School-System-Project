
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Adesuwa
 */
public class options implements Serializable {
    
    private String id;
    private String type;
    private String courseID;
    private String courseTitle;
    private String instructor;
    private String classCapacity;
    private String studentsEnrolled;
    private String status;
    
    
    public options(String id, String type)
    {
        this.id = id;
        this.type = type;
       
    }
    
   

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public String getInstructor() {
        return instructor;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public String getClassCapacity() {
        return classCapacity;
    }

    public void setClassCapacity(String classCapacity) {
        this.classCapacity = classCapacity;
    }

    public String getStudentsEnrolled() {
        return studentsEnrolled;
    }

    public void setStudentsEnrolled(String studentsEnrolled) {
        this.studentsEnrolled = studentsEnrolled;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    private courses course;

    public courses getCourse() {
        return course;
    }

    public void setCourse(courses course) {
        this.course = course;
    }
   
    
    
    public ArrayList<String> displayOpenCourse()//showing a list of open courses
    {
        ArrayList<String> displayOpenCourse = new ArrayList<>();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
           
        }
        
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/ukponmwana8241?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(DB_URL, "ukponmwana8241", "1596850");
            st = conn.createStatement();
            rs = st.executeQuery("select * from course where Status = 'open' ");
            
            while(rs.next())
            {
                course = new courses(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
                displayOpenCourse.add(rs.getString(1)  + ": " + rs.getString(2)); 
            } 
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
         
        }
        finally
        {
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return displayOpenCourse;
    } 
    
    private courses viewCourse;
    private String courseId;

    public courses getViewCourse() {
        return viewCourse;
    }

    public void setViewCourse(courses viewCourse) {
        this.viewCourse = viewCourse;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }
    
  
    
    public String viewCourses(String obj)//select to view open courses
    {
        int index = obj.indexOf(":");
        courseId = obj.substring(0,index);
       
       try
       {
           Class.forName("com.mysql.jdbc.Driver");
       }
       catch(Exception e)
       {
           e.printStackTrace();
          
       }
       final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/ukponmwana8241?useSSL=false";
       Connection conn = null;
       Statement st = null;
       ResultSet rs = null;
       try
       {
         conn = DriverManager.getConnection(DB_URL, "ukponmwana8241", "1596850");
         st = conn.createStatement();
         rs = st.executeQuery("select * from course where courseID = '" + courseId + "' and Status = 'open'");
         
         if(rs.next() && rs.getString(1).equals(courseId))
         {
             viewCourse = new courses(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
           
            
         }
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
       finally
       {
           try
           {
               conn.close();
               st.close();
               rs.close();
           }
           catch(Exception e)
           {
               e.printStackTrace();
           
           }             
       }
        return "viewCourse";       
    }
    
   
    //private courses courseInfo;
    ArrayList<String> search = new ArrayList<>();
   

//    public courses getCourseInfo() {
//        return courseInfo;
//    }
//
//    public void setCourseInfo(courses courseInfo) {
//        this.courseInfo = courseInfo;
//    }
    public ArrayList<String> getSearch() {
        return search;
    }

    public void setSearch(ArrayList<String> search) {
        this.search = search;
    }
    
    
    
    public ArrayList<String> search()
    {
         
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            
        }
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/ukponmwana8241?useSSL=false";
        Connection conn= null;
        Statement st = null;
        ResultSet rs = null;
        
        try
        {
            conn = DriverManager.getConnection(DB_URL, "ukponmwana8241", "1596850");
            st = conn.createStatement();
            rs = st.executeQuery("select * from course where courseID = '" + courseID + "'");
            
            while(rs.next())
            {
                 search.add(rs.getString(1) + ": " + rs.getString(2));
            }
            if(search.isEmpty())
                System.out.println("No such users found");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                rs.close();
                st.close();
                conn.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return search;
    }
    
    public String register()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return "Internal error";
            
        }
        
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/ukponmwana8241?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(DB_URL, "ukponmwana8241", "1596850");
            st = conn.createStatement();
            
            rs = st.executeQuery("select courseID from registration where studentID = '" + id + "'");
            
            if(rs.next())
            {
                return "you are registered";
            }
            else
            {
                st.executeUpdate("Insert into registration values('" + id + "', '" + courseID + "', 'enrolled')");
                return "registration succesfull";
            }
            

        }
        catch(SQLException e)
        {
            e.printStackTrace();
            return "Internal Error";
         
        }
        finally
        {
            try
            {
                conn.close();
                st.close();
                //rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
             
               
            }
        } 
        
    }
    
    private ArrayList<String> classSchedule = new ArrayList<>();
    private registration registerCourses;

    public ArrayList<String> getClassSchedule() {
        return classSchedule;
    }

    public void setClassSchedule(ArrayList<String> classSchedule) {
        this.classSchedule = classSchedule;
    }

    public registration getRegisterCourses() {
        return registerCourses;
    }

    public void setRegisterCourses(registration registerCourses) {
        this.registerCourses = registerCourses;
    }
    
    
    
    
    public ArrayList<String> classSchedule()//showing a list of open courses
    {
        ArrayList<String> classSchedule = new ArrayList<>();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
           
        }
        
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/ukponmwana8241?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(DB_URL, "ukponmwana8241", "1596850");
            st = conn.createStatement();
            rs = st.executeQuery("select * from registration where studentID = '" + id + "' ");
            
            while(rs.next())
            {
                registerCourses = new registration(rs.getString(1), rs.getString(2), rs.getString(3));
                classSchedule.add(rs.getString(1)  + ": " + rs.getString(2) + ":" + rs.getString(3)); 
            } 
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
         
        }
        finally
        {
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return classSchedule;
    } 
    
    public String dropCourse()
    {
          try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return "Internal error";
            
        }
        
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/ukponmwana8241?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(DB_URL, "ukponmwana8241", "1596850");
            st = conn.createStatement();
            int r = st.executeUpdate("delete from registration where courseID = '" + courseID + "' and studentID = '" + id + "'");
            
            st.executeUpdate("Update registration set status = 'unenrolled' where studentID = '" + id + "'");
            return "your course has been dropped";
           
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
            return "Internal Error";
         
        }
        finally
        {
            try
            {
                conn.close();
                st.close();
                //rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
                
             
               
            }
        } 
    }
    
    
    public ArrayList<String> teachingSchedule()
    {
        ArrayList<String> teachingSchedule = new ArrayList<>();
        
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            e.printStackTrace();
           
        }
        
        final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/ukponmwana8241?useSSL=false";
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try
        {
            conn = DriverManager.getConnection(DB_URL, "ukponmwana8241", "1596850");
            st = conn.createStatement();
            rs = st.executeQuery("select * from course where Instructor = '" + id + "'");
            
            while(rs.next())
            {
                
                 teachingSchedule.add(rs.getString(1)+ ":" + rs.getString(2) + ":" + rs.getString(3)+ ":" + rs.getString(4)+ ":" + rs.getString(5)+ ":" +rs.getString(6)); 
            } 
            
        }
        catch(SQLException e)
        {
            e.printStackTrace();
         
        }
        finally
        {
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        return teachingSchedule;  
    }
    
    private courses instructorInfo;
   

    public courses getInstructorInfo() {
        return instructorInfo;
    }

    public void setInstructorInfo(courses instructorInfo) {
        this.instructorInfo = instructorInfo;
    }

    
    
    
    
    public String viewSchedule(String obj)//select to view open courses
    {
        int index = obj.indexOf(":");
        courseID = obj.substring(0,index);
       
       try
       {
           Class.forName("com.mysql.jdbc.Driver");
       }
       catch(Exception e)
       {
           e.printStackTrace();
          
       }
       final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/ukponmwana8241?useSSL=false";
       Connection conn = null;
       Statement st = null;
       ResultSet rs = null;
       try
       {
         conn = DriverManager.getConnection(DB_URL, "ukponmwana8241", "1596850");
         st = conn.createStatement();
         rs = st.executeQuery("select * from course where Instructor = '" + id + "'and courseID = '"+ courseID + "'");
         
         if(rs.next())
         {
             instructorInfo = new courses(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
           
            
         }
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
       finally
       {
           try
           {
               conn.close();
               st.close();
               rs.close();
           }
           catch(Exception e)
           {
               e.printStackTrace();
           
           }             
       }
        return "instructorInfo";       
    }
}
